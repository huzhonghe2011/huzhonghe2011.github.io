const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

// 创建Express应用
const app = express();

// 创建http服务器
const server = http.createServer(app);

// 创建Socket.io服务器并将其附加到http服务器上
const io = socketIo(server);

// 设置静态文件目录
app.use(express.static('public'));

// 定义一个连接事件，用于监听客户端的连接
io.on('connection', (socket) => {
  console.log('用户已连接');

  // 监听来自客户端的聊天消息
  socket.on('chatMessage', (msg) => {
    // 向所有客户端广播消息
    io.emit('chatMessage', msg);
  });
// 假设服务器发送在线人数更新
socket.on('onlineCount', (count) => {
  const onlineCountElement = document.getElementById('online-count');
  onlineCountElement.textContent = `在线人数: ${count}`;
});
  // 监听断开连接事件
  socket.on('disconnect', () => {
    console.log('用户已断开连接');
    // 通知所有客户端更新在线人数
  io.emit('onlineCount', io.engine.clientsCount); // 获取当前在线人数
  });
});
// 设置根路径返回一个简单的 HTML 页面
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

// 设置服务器监听端口
server.listen(3000, () => {
  console.log('服务器正在运行在 http://localhost:3000');
});
