﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ExtraComponent.Dependence;

public enum EASEIO
{
    NULL,
    IN,
    OUT,
    INOUT
}

public enum EASE
{
    NULL,

    SINE,
    QUAD,
    CUBIC,
    QUART,
    QUINT,
    EXPO,
    CIRC,
    BACK,
    ELASTIC,
    BOUNCE,

    SINEIN,
    SINEOUT,
    SINEINOUT,
    QUADIN,
    QUADOUT,
    QUADINOUT,
    CUBICIN,
    CUBICOUT,
    CUBICINOUT,
    QUARTIN,
    QUARTOUT,
    QUARTINOUT,
    QUINTIN,
    QUINTOUT,
    QUINTINOUT,
    EXPOIN,
    EXPOOUT,
    EXPOINOUT,
    CIRCIN,
    CIRCOUT,
    CIRCINOUT,
    BACKIN,
    BACKOUT,
    BACKINOUT,
    ELASTICIN,
    ELASTICOUT,
    ELASTICINOUT,
    BOUNCEIN,
    BOUNCEOUT,
    BOUNCEINOUT
}

public class Tween : MonoBehaviour
{
    public Tween(UPDATE Type = UPDATE.FIXED)
    {
        gameObject.AddComponent<Tween>();
        animUpdataType = Type;
    }

    UPDATE animUpdataType = UPDATE.FIXED;
    float animX = 0.0f;
    float animTime = 1.0f;
    bool animing = false;
    float refValue = 0;
    float valueOld = 0.0f;
    float processValue = 0.0f;
    EASE animType = EASE.NULL;
    bool autoDestroy = true;
    public float AnimX { get => animX; set => animX = value; }
    public float AnimTime { get => animTime; }
    public UPDATE AnimUpdateType { get => animUpdataType; }
    public bool Animing { get => animing; }
    public float RefValue { get => refValue; set => refValue = value; }
    public float ValueOld { get => valueOld; }
    public float ProcessValue { get => processValue; }
    public EASE AnimType { get => animType; }
    public bool AutoDestroy { get => autoDestroy; set => autoDestroy = value; }
    

    #region EaseMethod
    public float AnimValue(EASE EaseType,float x)
    {
        float c1 = 1.70158f;
        float c2 = c1 * 1.525f;
        float c3 = c1 + 1.0f;
        float c4 = (2 * Mathf.PI) / 3;
        float c5 = (2 * Mathf.PI) / 4.5f;
        float n1 = 7.5625f;
        float d1 = 2.75f;
        switch (EaseType)
        {
            case EASE.SINEIN:
                return 1 - Mathf.Cos((x * Mathf.PI) / 2);
            case EASE.SINEOUT:
                return Mathf.Sin((x * Mathf.PI) / 2);
            case EASE.SINEINOUT:
                return -(Mathf.Cos(Mathf.PI * x) - 1) / 2;
            case EASE.QUADIN:
                return x * x;
            case EASE.QUADOUT:
                return 1 - (1 - x) * (1 - x);
            case EASE.QUADINOUT:
                return x < 0.5 ? 2 * x * x : 1 - Mathf.Pow(-2 * x + 2, 2) / 2;
            case EASE.CUBICIN:
                return x * x * x;
            case EASE.CUBICOUT:
                return 1 - Mathf.Pow(1 - x, 3);
            case EASE.CUBICINOUT:
                return x < 0.5 ? 4 * x * x * x : 1 - Mathf.Pow(-2 * x + 2, 3) / 2;
            case EASE.QUARTIN:
                return x * x * x * x;
            case EASE.QUARTOUT:
                return 1 - Mathf.Pow(1 - x, 4);
            case EASE.QUARTINOUT:
                return x < 0.5 ? 8 * x * x * x * x : 1 - Mathf.Pow(-2 * x + 2, 4) / 2;
            case EASE.QUINTIN:
                return x * x * x * x * x;
            case EASE.QUINTOUT:
                return 1 - Mathf.Pow(1 - x, 5);
            case EASE.QUINTINOUT:
                return x < 0.5 ? 16 * x * x * x * x * x : 1 - Mathf.Pow(-2 * x + 2, 5) / 2;
            case EASE.EXPOIN:
                return x == 0 ? 0 : Mathf.Pow(2, 10 * x - 10);
            case EASE.EXPOOUT:
                return x == 1 ? 1 : 1 - Mathf.Pow(2, -10 * x);
            case EASE.EXPOINOUT:
                return x == 0
                  ? 0
                  : x == 1
                  ? 1
                  : x < 0.5 ? Mathf.Pow(2, 20 * x - 10) / 2
                  : (2 - Mathf.Pow(2, -20 * x + 10)) / 2;
            case EASE.CIRCIN:
                return 1 - Mathf.Sqrt(1 - Mathf.Pow(x, 2));
            case EASE.CIRCOUT:
                return x < 0.5
                  ? (1 - Mathf.Sqrt(1 - Mathf.Pow(2 * x, 2))) / 2
                  : (Mathf.Sqrt(1 - Mathf.Pow(-2 * x + 2, 2)) + 1) / 2;
            case EASE.CIRCINOUT:
                return c3 * x * x * x - c1 * x * x;
            case EASE.BACKIN:
                return 1 + c3 * Mathf.Pow(x - 1, 3) + c1 * Mathf.Pow(x - 1, 2);
            case EASE.BACKOUT:
                return x < 0.5
                  ? (Mathf.Pow(2 * x, 2) * ((c2 + 1) * 2 * x - c2)) / 2
                  : (Mathf.Pow(2 * x - 2, 2) * ((c2 + 1) * (x * 2 - 2) + c2) + 2) / 2;
            case EASE.BACKINOUT:
                return x == 0
                  ? 0
                  : x == 1
                  ? 1
                  : -Mathf.Pow(2, 10 * x - 10) * Mathf.Sin((x * 10.0f - 10.75f) * c4);
            case EASE.ELASTICIN:
                return x == 0
                  ? 0
                  : x == 1
                  ? 1
                  : Mathf.Pow(2, -10 * x) * Mathf.Sin((x * 10.0f - 0.75f) * c4) + 1.0f;
            case EASE.ELASTICOUT:
                return x == 0
                  ? 0
                  : x == 1
                  ? 1
                  : Mathf.Pow(2, -10 * x) * Mathf.Sin((x * 10.0f - 0.75f) * c4) + 1;
            case EASE.ELASTICINOUT:
                return x == 0
                  ? 0
                  : x == 1
                  ? 1
                  : x < 0.5
                  ? -(Mathf.Pow(2.0f, 20.0f * x - 10.0f) * Mathf.Sin((20.0f * x - 11.125f) * c5)) / 2.0f
                  : (Mathf.Pow(2.0f, -20.0f * x + 10.0f) * Mathf.Sin((20.0f * x - 11.125f) * c5)) / 2.0f + 1.0f;
            case EASE.BOUNCEIN:
                return 1 - EaseOutBounce(1 - x);
            case EASE.BOUNCEOUT:
                if (x < 1 / d1)
                {
                    return n1 * x * x;
                }
                else if (x < 2 / d1)
                {
                    return n1 * (x -= 1.5f / d1) * x + 0.75f;
                }
                else if (x < 2.5 / d1)
                {
                    return n1 * (x -= 2.25f / d1) * x + 0.9375f;
                }
                else
                {
                    return n1 * (x -= 2.625f / d1) * x + 0.984375f;
                }
            case EASE.BOUNCEINOUT:
                return x < 0.5
                  ? (1 - EaseOutBounce(1 - 2 * x)) / 2
                  : (1 + EaseOutBounce(2 * x - 1)) / 2;
        }
        return 0.0f;
    }

    public float EaseOutBounce(float x)
    {
        float n1 = 7.5625f;
        float d1 = 2.75f;

        if (x < 1 / d1)
        {
            return n1 * x * x;
        }
        else if (x < 2 / d1)
        {
            return n1 * (x -= 1.5f / d1) * x + 0.75f;
        }
        else if (x < 2.5 / d1)
        {
            return n1 * (x -= 2.25f / d1) * x + 0.9375f;
        }
        else
        {
            return n1 * (x -= 2.625f / d1) * x + 0.984375f;
        }
    }

    public float AnimValue(EASE EaseType, EASEIO EaseIO, float X)
    {
        switch (EaseIO)
        {
            case EASEIO.IN:
                switch (EaseType)
                {
                    case EASE.SINE:
                        return 1 - Mathf.Cos((X * Mathf.PI) / 2);
                }
                break;
            case EASEIO.OUT:
                switch (EaseType)
                {
                    case EASE.SINE:
                        return Mathf.Sin((X * Mathf.PI) / 2);
                }
                break;
            case EASEIO.INOUT:
                switch (EaseType)
                {
                    case EASE.SINE:
                        return -(Mathf.Cos(Mathf.PI * X) - 1) / 2;
                }
                break;
        }
        return 0.0f;
    }
    #endregion

    public void AnimSet(EASE EaseType, ref float Variable, float Value, float Time = 1.0f)
    {
        animX = 0.0f;
        animType = EaseType;
        refValue = Variable;
        valueOld = refValue - 0.0f;
        processValue = Value;
        animTime = Time;
    }

    public void Anim(ref float Variable)
    {
        Variable = refValue;
    }

    #region UnityUpdate
    void FixedUpdate()
    {
        if(animUpdataType == UPDATE.FIXED) { AnimUpdate(); }
    }

    void Update()
    {
        if (animUpdataType == UPDATE.FRAME) { AnimUpdate(); }
    }
    #endregion

    #region AnimUpdate
    public void AnimUpdate()
    {
        animing = true;
        switch(animUpdataType)
        {
            case UPDATE.FIXED:
                if(animX < animTime)
                {
                    animX += Time.deltaTime * (1 / animTime);
                }
                else
                {
                    animX = 1.0f;
                    animing = false;
                }
                refValue = valueOld + AnimValue(animType, animX) * processValue;
                valueOld = refValue - AnimValue(animType, animX) * processValue;
                break;
            case UPDATE.FRAME:
                if (animX < Mathf.Round(animTime))
                {
                    animX += 1 / Mathf.Round(animTime);
                }
                else
                {
                    animX = 1.0f;
                    animing = false;
                }
                refValue = valueOld + AnimValue(animType, animX) * processValue;
                valueOld = refValue - AnimValue(animType, animX) * processValue;
                break;
        }
    }

    public void AnimJust(EASE EaseType, ref object Variable, float Value, float AnimTime = 1.0f)
    {
        animing = true;
        switch (animUpdataType)
        {
            case UPDATE.FIXED:
                if (animX < animTime)
                {
                    animX += Time.deltaTime * AnimTime;
                }
                else
                {
                    animX = 1.0f;
                    animing = false;
                }
                Variable = (float)valueOld + (float)AnimValue(EaseType, animX) * Value;
                valueOld = (float)refValue - (float)AnimValue(EaseType, animX) * Value;
                break;
            case UPDATE.FRAME:
                if (animX < Mathf.Round(animTime))
                {
                    animX += 1 / Mathf.Round(AnimTime);
                }
                else
                {
                    animX = 1.0f;
                    animing = false;
                }
                Variable = (float)valueOld + (float)AnimValue(EaseType, animX) * Value;
                valueOld = (float)refValue - (float)AnimValue(EaseType, animX) * Value;
                break;
        }
    }
    #endregion
}
